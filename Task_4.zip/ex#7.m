format long
a=1;
b=2;
eps=10^(-6);
i=0;
while abs(b-a)>=eps
c=(a+b)/2;
if(c^6-c-1==0)
    x=c;
else
    if((a^6-a-1)*(c^6-c-1)>0)
        a=c;
        b=b;
    else
        a=a;
        b=c;
    end
end
if abs(b-a)<eps
    x=(a+b)/2;
end
i=i+1;
y=abs(b-a);
end
fprintf('La pasul %i solutia este %f iar lungimea intervalului este %f \n',i,x,y)