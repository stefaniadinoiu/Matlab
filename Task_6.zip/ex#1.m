file=fopen('A.txt', 'r')
A=fscanf(file, '%f %f %f ',[4 4]);
A=A'

file=fopen('b.txt', 'r')
b=fscanf(file, '%f',[1 4]);
b=b'

L=A(:,1)
C=A(1,:)
n=length(L)
m=length(C)

if m==n
    disp('E patratica.')
    patr=1;
else
    disp('EROARE: Nu e patratica.')
    patr=0;
end
    
ok=0;
if patr==1
for i=1:n
    for j=1:m
        if i<j
            if A(i,j)~=0
                ok=ok+1;
            end
        end
    end
end
end
if ok==0
    'EROARE: Nu e inferior triunghiulara.'
    inft=0;
else
    'E inferior triunghiulara.'
    inft=1;
end

if(patr==1 & inft==1)
    if(det(A)~=0)
       'E inversabila'
        inv=1;
    else
        'EROARE: Nu e inversabila'
        inv=0;
    end
end

if(patr==1 & inft==1 & inv==1)
if length(b)==m
   'A si b sunt compatibili.'
  comp=1;
else
    'A si b nu sunt compatibili.'
    comp=0;
end
end


if comp==1
x(n)=b(n)/A(n,n);
for i=n-1:-1:1
    s=0;
    for j=i+1:n 
        s=s+A(i,j)*x(j);
    end
    x(i)=(1/A(i,i))*(b(i)-s);
end
end
disp(x)