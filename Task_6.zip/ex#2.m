
dlmwrite('matrice.in',randi(25,5,5);
A=dlmread('matrice.in')
b=dlmread('b.in')

sz=size(A)
if sz(1) ~=sz(2)
    disp('matricea nu este patratica')
elseif A~=transpose(A)
    disp('matricea nu este simetrica')
elseif EstePozitivDefinita(A)==0
else
    disp('nu este pozitiv definita')
end

function r=EstePozitivDefinita(A)
for i=1:size(A,1)
    for j=1:size(A,2)
        B=A;
        B(i,:)=[];
        B(:,j)=[];
        if det(B)<0
            r=0;
            return ;
        end
    end
end
r=1;
return;
end
    