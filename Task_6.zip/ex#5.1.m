f(1)=111

for i=112:999
    
    a =  mod(i,10)
    b = fix((mod(i,100)) /10)
    c = fix(i/100)
  if ( a == b && b == c) f(end+1) = i;
         %D = 1+(i*4)
        %if(D>0 && sqrt(D)==fix(sqrt(D))) 
       
      end
end

for i=1000:9999
    
    a =  mod(i,10)
    b = fix((mod(i,100)) /10)
    c = fix(i/1000)
    d = fix(mod(i,1000)/100)
  if ( a == b && b == c) f(end+1) = i;
         %D = 1+(i*4)
        %if(D>0 && sqrt(D)==fix(sqrt(D))) 
       
      end
end
disp(f)