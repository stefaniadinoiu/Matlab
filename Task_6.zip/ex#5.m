clc,clear


n=5;
%
x=100;
% S=0;
%

 
for k=0:n
%    
 S=S+exp(k)*x^k/factorial(k)
%
 end



syms x 

e
S=1;


for k=1:n
 
   S=((e*x)*(S*k+S))/factorial(k)
    
   expand(S)

end