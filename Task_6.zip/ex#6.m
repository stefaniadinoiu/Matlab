a=24
E=1/16

x(1)=a
er(1)=E+1
n=0
i=2;
  while ((er(i-1)==E) | (er(i-1)>E))
    x(i)=(x(i-1)+(a/x(i-1)))/2;
    er(i)=abs(sqrt(a)-x(i));
    n=n+1;
    i=i+1;
end

disp(n),disp(x(n)),disp(sqrt(a)),disp(er(n))