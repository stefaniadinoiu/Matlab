clear 
x(1)=1
x(2)=1
N=8

for i=3:(N^2)
  x(i)=x(i-1)+x(i-2);
end


A=reshape( x,[N,N]);
A=A'

file=fopen('A1.txt', 'w');
%A=fprintf(file, '%d %d %d %d \n ',[N N]);

