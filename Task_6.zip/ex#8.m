A=dlmread('matrice.in')

b=dlmread('b.in')

%
A=triu(randi(20,5))
%
b=randi(20,1 ,5)

sz=size(A)
x=[];


if sz(1) ~=sz(2)
    
   disp('matricea nu este patratica')
     

   else if ~istriu(A)
  
        disp('matricea nu este superior triunghiulara')

   else  if det(A)==0
    disp('matricea nu este inversabila')

   else  if sz(2)~=length(b)
    dips('a si b nu sunt compatibile')

   else
    for i=sz(1):-1:1

        b(1:i-1)=b(1:i-1)-b(i)*A(i,1:i-1)
   
           x(i)=b(i)
        A(i,1:i)=0
   
    end

   end  

x