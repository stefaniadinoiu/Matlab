r=15;
h=input('Inaltimea:');
if (h>0&&h<15)
    volum1=pi*(h^2)*(r-h/3)
else
    if(h>=15&&h<=55)
        volumul2=(4/6)*pi*r^3+pi*(r^2)*(h-15)
    else
        if(h>55&h<=70)
            h=h-55
            volumul3=(4/6)*pi*r^3+pi*(r^2)*40+((4/6)*pi*r^3-pi*((15-h)^2)*(r-(15-h)/3))
    end
    end
end
v=[15:0.1:55];
v1=[0:0.5:15];
v2=[0:0.1:40];
v3=[15 14.5 14 13.5 13 12.5 12 11.5 11 10.5 10 9.5 9 8.5 8 7.5 7 6.5 6 5.5 5 4.5 4 3.5 3 2.5 2 1.5 1 0.5 0];
v4=[55:0.5:70];
volumul11=[];
volumul12=[];
volumul13=[];
    for i=1:length(v1)
    volumul11(end+1)=pi*(v1(i)^2)*(r-v1(i)/3);
    end
    for j=1:length(v2)
        volumul12(end+1)=(4/6)*pi*r^3+pi*(r^2)*v2(j);
    end
    for z=1:length(v3)
         volumul13(end+1)=(4/6)*pi*r^3+pi*(r^2)*40+((4/6)*pi*r^3-pi*(v3(z)^2)*(r-v3(z)/3));
    end
figure(1)
plot(v1,volumul11);
hold on
plot(v,volumul12);
plot(v4,volumul13);
hold off