%Factorizarea cholesky


A=[10 5 1 3;5 10 2 8;1 2 1 4;3 8 4 20]
y=size(A);
ok=0;
for i=1:y(1)
    for j=i+1:y(1)
        if( A(i,j)~=A(j,i))
            ok=1;
        end
    end
end
s=0;
if(ok==0)
    s=1;
end
p=0;
if(y(1)==y(2))
    p=1;
end
if(s==1 && p==1)
    disp('A este simetrica si patratica')
else disp('A NU este simetrica si patratica')
end
B=0;
pd=1;
for i=1:y(1)
    for x=1:i
        for z=1:i
            B(x,z)=A(x,z);
        end
    end
    d=det(B);
    if(d<0)
        pd=0;
        %break
    end
end
if(pd==1)
    disp('ESTE pozitiv definita')
else disp('NU e pozitiv definita')
end
if(s==1 && p==1 && pd==1)
B=zeros(y(1),y(1));
B(1,1)=sqrt(A(1,1));
for i=2:y(1)
    B(1,i)=A(1,i)/B(1,1);
end
for i=1:y(1)
    for j=1:y(1)
        if(i==j)
            s=0;
           for k=1:i-1
              s=s+B(i,k)^2;
           end
           B(i,j)=sqrt(A(i,j)-s);
        else
            s=0;
            for k=1:j-1
               s=s+B(i,k)*B(j,k);
            end
            B(i,j)=(A(i,j)-s)/B(j,j);
        end
    end
end
for i=1:y(1)
    for j=i+1:y(1)
       B(i,j)=0;
    end
end
B
C=chol(A)
else
    disp('Nu se poate construi')
end