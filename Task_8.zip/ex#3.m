a=[1 0 0;1 1 0;1 1 1]
b=[1 2 3]'
f=[];
msg1='Matricea nu este patratica';
msg2='Matricea nu este superior triunghiulara';
msg3='Matricea nu este inversabila';
msg4='a si b nu sunt compatibile';
if(length(a)>length(b)&&length(a)<length(b))
  error(msg1)
end
for i=1:length(a)
    for k=1:length(b)
        if(a(i,abs(i-k)+1)<0&&a(i,abs(i-k)+1)>0)
           error(msg2)
        end      
    end
end
if(det(a)==0)
    error(msg3)
end

for i=1:length(b)
    s=b(i);
    if(i>1)
        for k=1:i-1
            s=s-a(i,k)*f(k);
        end
    end
    f(end+1)=s/a(i,i);
end
f