a=[1 1 1;0 2 1;0 0 1]
b=[3;2;1]
f=[];

msg1='Matricea nu este patratica';
msg2='Matricea nu este superior triunghiulara';
msg3='Matricea nu este inversabila';
msg4='a si b nu sunt compatibile';
if(length(a)>length(b)&&length(a)<length(b))
  error(msg1)
end
for i=1:length(a)
    for k=1:length(b)
        if(a(i,abs(i-k)+1)<0&&a(i,abs(i-k)+1)>0)
           error(msg2)
        end      
    end
end
if(det(a)==0)
    error(msg3)
end
i=length(a);
while(i>0)
    s=b(i);
    if(i<length(a))
        for k=i+1:length(a)
            s=s-a(i,k)*f(k);
        end
    end
    f(i)=s/a(i,i);
    i=i-1;
end
f