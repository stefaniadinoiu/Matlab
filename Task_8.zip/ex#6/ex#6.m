m=input('Primul numar:');
n=input('Al doilea numar:');
fid=fopen('1.txt','w');
if(m>0&&n>0&&n>m)
for i=m:n
    nr=0;
    for j=1:i
        if rem(i,j)==0
            nr=nr+1;
        end
    end
    if nr==2
        fprintf(fid,' %i ',i);
    end
end
end
    