3n=input('n=')
x=[0:0.01:n];
x(1)=[];
y=[];
z=[];
w=[];
for i=1:length(x)
   y(end+1)=sqrt(n^2-x(i)^2);
end
for i=1:length(x)
    z(end+1)=-y(i);
    w(end+1)=-x(i);
end
figure(1)
plot(x,y,'LineStyle','-','Color','k','LineWidth',12)
legend('grafic')
xlabel('x')
ylabel('y')
title('GRAFIC')
hold on
plot(x,z,'LineStyle','-','Color','k','LineWidth',12)
plot(w,y,'LineStyle','-','Color','k','LineWidth',12)
plot(w,z,'LineStyle','-','Color','k','LineWidth',12)
hold off